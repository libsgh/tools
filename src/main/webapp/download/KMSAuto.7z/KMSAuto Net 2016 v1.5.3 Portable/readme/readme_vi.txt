﻿
                        KMSAuto Net 2016 Portable bởi Ratiborus,
                                   'Công ty' MSFree.


                                           Yêu cầu hệ thống:
 				 ————————————————————————————————
Các sản phẩm VL: Windows Vista, 7, Windows 8, 8.1, 10, Server 2008, 2008 R2, 2012,
2012 R2, Office 2010/2013/2016.

			  		    Mô tả:
				 ————————————————————————————————
KMSAuto Net - là gải pháp tự động kích hoạt các phẩm của Microsoft qua KMS, bao gồm một số hệ điều hành sau:
Windows Vista, 7, 8, 8.1, 10, Server 2008, 2008 R2, 2012, 2012 R2, 2016 VL và Retail
Nó cũng có thể kích hoạt cho Office 2010, 2013, 2016 VL.
Ngoài ra, chương trình còn kích hoạt cho:
	Windows 8.1 Single Language;
	Windows 8.1 Core;
	Windows 8.1 Core N;
	Windows 8.1 Pro WMC;
	Windows Embedded 8.1 Industry Pro;
	Windows Server 2012 R2 Standard;
	Windows Server 2012 R2 Datacenter.
Chương trình được xây dựng dựa trên KMS Server Service của mikmik38 (MDL).

  
       				         Sử dụng chương trình:
				—————————————————————————————————
Chạy KMSAuto Net.exe với với quyền quản trị và sử dụng. Nếu bạn cần các tính năng khác của
chương trình, hãy bật chế độ chuyên nghiệp. Nút Bật/Tắt chế độ chuyên nghiệp ở thẻ "About".
Cách dễ nhất để sử dụng chương trình là để chọn chế độ tự động. Tất cả những gì bạn cần làm
là nhấp vào nút kích hoạt và tạo một lịch biểu để kích hoạt lại cũng chỉ với một cú nhấp
chuột.

Mẹo: Trước tiên bạn chỉ cần kích hoạt Windows và Office bằng cách nhấn nút kích hoạt ở trang
chính là xong. Khi bạn chắc chắn rằng việc kích hoạt đã diễn ra, và không muốn nó hết hạn sau
180 ngày, bạn có thể tạo một lịch biểu để tự động kích hoạt lại sau 25 ngày.
Nếu bạn không muốn kích hoạt tự động với 180 ngày sử dụng, bạn có thể bật chế độ chuyên nghiệp,
vào "Tiện ích" và tiến hành kích hoạt thủ công. Rất đơn giản, bạn chỉ cần nhập key GVLK cho
phiên bản Windows thích hợp và sau đó cố gắng nhấn kích hoạt một lần nữa là xong.


				          Thông tin bổ sung:
				—————————————————————————————————

Để kích hoạt Windows 8.1, TAP adapter phải được cài đặt trực tiếp và sử dụng địa chỉ IP là
10.3.0.2-254 hoặc sử dụng một trình điều khiển đặc biệt. Tất cả các tính năng này đã được bao
gồm trong chương trình.
Để kích hoạt qua LAN, TAP không được tạo và kích hoạt với một địa chỉ trong mạng của máy tính.
Nếu bạn muốn cấu hình lại chương trình do nó không làm việc tốt - kiểm tra và nhấn vào 
"Reset chương trình." Mọi thiết đặt sẽ trở về mặc định.


			Thông tin bổ sung về các thành phần của chương trình:
				—————————————————————————————————
/win=act	         - Chạy chương trình trong quiet mode, kích hoạt Windows
		  và thoát khỏi chương trình.
/off=act	         - Chạy chương trình trong quiet mode, kích hoạt Office
		  và thoát khỏi chương trình.
/log=yes	         - Chạy chương trình trong quiet mode, tạo một tệp ActStatus.log
		  và thoát khỏi chương trình.
/kmsset=yes      - Chạy chương trình trong quiet mode, cài đặt KMS-Service và thoát khỏi chương trình.
 	            Nó chỉ dành cho KMS-Service, without TAP, WinDivert, Hook.
/kmsdel=yes      - Chạy chương trình trong quiet mode, loại bỏ KMS-Service và thoát khỏi chương trình.
/key=yes	         - Chạy chương trình trong quiet mode, cài đặt key Windows key và thoát khỏi chương
                           trình.
/task=yes	         - Chạy chương trình trong quiet mode, tạo lịch biểu để Windows và Office
   	           tự kích hoạt lại mỗi 25 ngày.
/taskrun=yes      - Chạy chương trình trong quiet mode, chạy lịch biểu để kích hoạt Windows và 
   	           Office, sau đó thoát khỏi chương trình.
/convert=	         - Chạy chương trình trong quiet mode, chuyển đổi phiên bản Windows 
   	           sau đó thoát khỏi chương trình.
	           Key có sẵn: win81pro, win81ent, win81, win81sl, win81wmc
	           Sau khi sử dụng các chức năng này, bạn cần khởi động lại máy.
/sound=yes	- Bật âm thanh.
/sound=no	- Tắt âm thanh.
		  
				—————————————————————————————————
Quá trình kích hoạt sẽ được thực hiện với các thiết đặt được xác định trong thẻ KMS-Service.


				—————————————————————————————————
Khi bạn chuyển chương trình sang một máy tính khác, bạn cần reser chế độ Tự động.
Kích hoạt tự động vẫn có thể sử dụng, nhưng các chế độ mới không thể tối ưu cho máy
tính mới của bạn.
Để reset chế độ tự động về trạng thái ban đầu, bạn cần chuyển sang một chế độ khác,
và chọn lại chế độ tự động lần nữa. Mọi thứ sẽ được Reset về trạng thái ban đầu.

		 Làm thế nào để kích hoạt chương trình được tích hợp KMS?				
				—————————————————————————————————
Chương trình có thể thực hiện việc kích hoạt với KMS server Emulator bằng nhiều cách khác nhau.
Vì sao phải dùng nhiều cách?: cách thông thường khi kết nối đến máy chủ kích hoạt sẽ sử dụng
local host (127.0.0.2-254). Nhưng nó đã bị chặn trên Windows 8.1. 
Tất cả các phương pháp được thiết kế để đánh lạc hướng hệ thống và tiến hành kích hoạt, làm sao
nó "nghĩ ra" KMS server không có trên máy tính của bạn, mà ở một nơi nào đó rất xa trên Internet.
				  
						  
		     Tổng quan về các chế độ hoạt động của chương trình:
				—————————————————————————————————
Auto	 - Chương trình sẽ cố gắng để tự động tìm cách phù hợp nhất để kích hoạt hệ thống của
                   bạn. Nó sẽ nỗ lực để kích hoạt Windows và Office bằng bất cứ giá nào và cách gì có
                   trên hệ thống của bạn, và một trong số đó sẽ giúp bạn kích hoạt thành công.
                   Để thiết lập về ban đầu, bạn chuyển sang một chế độ khác rồi chọn lại chế độ Tự động. 
	   Chế độ này là mặc định.	
Hook        - Phương pháp này dựa vào việc thay đổi tập tin hệ thống bạn đầu bằng một cách đặc biệt.
                   Phiên bản mới của phương pháp này làm việc mà không cần thay thế tập tin hệ thống.
WinDivert - Một trình điều khiển được cài đặt trong hệ thống và tạo mỗi trường mô phỏng để kết nối 
                  đến máy chủ KMS.	  
NoAuto   - Trong chế độ này, chương trình sẽ không chạy ở chế độ tự động, mà bạn phải tự tạo ra
                  cách để kích hoạt. Chế độ này chỉ dành cho những người sử dụng chuyên nghiệp.:)	
TAP        -  Hệ thống của bạn là một thiết bị ảo. Kích hoạt bằng TAP có thể thực hiện thông qua hoặc
	  ngay trên máy ảo này. Chương trình đã được kèm sẵn cho bạn 2 TAP adapter. Nếu bạn đã
                  cài đặt một trong 2 Adapter, chương trình sẽ sử dụng Adapter còn lại để kích hoạt, để 
                 đảm bảo Adapter còn lại của bạn còn nguyên vẹn.		   
* Tên của các chế độ được hiển thị trên thẻ Hệ thống (System) - Nhấn vào tên của chế độ bạn chọn để bắt đầu thiết lập.

				     Các tùy chọn KMSSS.exe
				—————————————————————————————————
Quy định về tham số của dòng lệnh:
  -Port <Giá trị của Port> - KMS Port. Nằm trong khoảng từ 1 đến 65535
  -PWin <PID> - Windows PID
  -PO14 <PID> - Office 2010 PID
  -PO15 <PID> - Office 2013 PID
  -AI <Interval> - Thời gian kích hoạt. Nằm trong khoảng từ 15 đến 43200 phút
  -RI <Interval> - Thời gian làm mới. Nằm trong khoảng từ 15 đến 43200 phút
  -Debug - Detailed info.
  -Log - Tệp Log đã kích hoạt.
  -IP - Hiện địa chỉ IP của các máy trạm.
  -Hwid <HWID> - Machine Hardware Hash.
		   
	                          —————————————————————————————————
Chương trình yêu cầu .NET Framework 4.5
Để chương trình hoạt động có hiệu quả, bạn cần thêm KMSSS.exe vào DS loại trừ 
của trình diệt Virut!. Hoặc tắt trình duyệt Virut tạm thời trong thời gian kích hoạt.

Thỉnh thoảng KMS-Service không được cài đặt đúng cách, vì nhiều lý do khác nhau.
Bạn cần thử "Loại bỏ KMS-Service" 2-3 lần và khởi động lại máy tính.
Khi bạn làm việc với chương trình bạn nên đánh dấu vào tùy chọn "Lưu các thiết đặt
vào trong thư mục chương trình". Trong TH này, các tập tin cấu hình sẽ được lưu 
vào thư mục chương trình nếu không thì ở C:\Users\username\AppData\Local\MSfree Inc.

                         	 —————————————————————————————————
KMS Log Analyzer.xlsm các phiên bản trước không tương thích với KMS Server Service v1.1.7.
Để bảo vệ các mục cũ cần công cụ cần phải chuyển đến mục mới.
KMS Log Analyzer hỗ trợ các thao tác sao chép/dán.

				  "I wasn't able to activate!!!"
  	                        —————————————————————————————————
Perhaps you have a non VL product, not intended for activation of KMS-Service, for instance 
Windows 7 Ultimate can't support KMS activation, or your antivirus blocks the activation.
If an antivirus is the culprit you can do the following: in the "System" tab click on the 
blue label "KMS-Service" and in the window that appears remove the check mark. Then add the 
folder to exceptions in your antivirus program.

                         	 —————————————————————————————————
Tối muốn gửi lời cảm ơn tới mikmik38, nếu không có anh ấy, công cụ sẽ không hoàn hảo
như thế này. Ngoài ra còn có Hotbird64 với KMS Client của anh ấy, Evgeny972 và tất cả 
các bạn trên forum.ru-board.com đã trực tiếp sử dụng và thử nghiệm chương trình.
                                                                 
									 Ratiborus

																 
Changelog:
v1.5.3
 -Added new GVLK Keys for Windows.

v1.5.2
 -KMS Server Service v2.0.4.
 -Added new GVLK Keys for Windows.

v1.5.1
 -Change the version of TAP interface.

v1.5.0
 -Fixed minor bugs.

v1.4.9
-Added Keys for Windows Server 2016 Essentials.
-KMS Server Service v2.0.3.

v1.4.8
 -Added Keys for Windows Server 2016.

v1.4.7
 -New KMS-Service.

v1.4.6
 -Added Keys for Windows 10 and Office 2016.

v1.4.5
 -Fixed minor bugs.

v1.4.4
 -Small changes in program code.

v1.4.3
 -Small changes in program code.

v1.4.2
 -Changes in program for compatibility with antivirus software.

v1.4.0
 -Added: Conversion from Office 2016 Mondo.

v1.3.9
 -Conversion from Office 2016 Word, Excel, Access,
  OneNote, OutLook, PowerPoint, Publisher RETAIL to VL.

v1.3.8
 -Fixed: mapping display buttons when the font is enlarged to 125%.
 -Added: Display the license expiration date (180 days 0 hours 0 minutes).
 -Added in "Other utilities" restore system files from the disk with your 
  version/edition of Windows.


v1.3.7
 -Fixed: Encoding readme_ru.txt.
 -Added readme.txt in the Bulgarian language.
 -Utility to save activation MSActBackUp v1.0.8.


v1.3.6
 -Updated program ProduKey v1.70 to v1.80.
 -Fixed: Setting keys for Office 2016.
 -Fixed: The task in the scheduler runs every 10 days.

v1.3.5
 -Updated ProduKey v1.66 to v1.70.
 -New TAP driver to support Windows 10. A random IP address is used and when the activation fails check box is cleared.
 -Re-compiled KMS Service. So antivirus software will not detect it as threat/false positive.
 -Included utility MSActBackUp.
 -Added Keys for Windows 10 and Office 2016.
 -Conversion from Office 2016 RETAIL to VL.
 -If Office is not installed, the button "Activate Office" is disabled.
 -In the "About" tab you can find a link to a page with my programs.
 -Added program for Windows 10 "Show or hide updates"

v1.3.4
 -Chương trình được thay đổi để tương thích với các phần mềm diệt virus.

v1.3.3
 -Thêm tính năng chuyển đổi Office 2013 OfficeProPlus, VisioPro, ProjectPro
  RETAIL License chưa kích hoạt trên Windows 7, 8, 8.1, 10 sang KMS Client.

v1.3.2
 -Thay đổi nhỏ trong giao diện, tương thích với Windоws Technical Preview.
 -Thêm ngôn ngữ tiêng Pháp, cảm ơn Coleo.

v1.3.1.b4
 -Tích hợp tính năng mới từ heos (ru-board.com) vào chương trình.
   Tính năng mới sẽ giúp bạn tìm kiếm các thiết đặt và cập nhật đã lỗi thời của 
   Office 2010/2013 và cho phép bạn xóa bỏ chúng.

v1.3.1 b3
 -Hỗ trợ chuyển đổi ngôn ngữ hiển thị trong chương trình.

v1.3.1.b2
 - Sửa lỗi khi thiết đặt các tham số trong dòng lệnh để tạo một tác vụ theo lịch trình.

v1.3.1.b1
 -Thêm tùy chọn để kích hoạt Windows Technical Preview, Windows 10.

v1.3.0
 -Thêm tùy chọn để kích hoạt Windows 8.1 with Bing, Windows 8.1 Single Language with Bing,
  và Windows 8.1 Pro for Education.

v1.2.8
 -Nâng cấp ProduKey từ v1.65 lên v1.66.
 -Thay thế phương pháp SECO Injector bằng SppPatcher.
 -Sửa lỗi hiển thị "Thời gian kích hoạt" ở các phiên bản ES, VI, UA.

v1.2.7
 -KMS Log Analizer sẽ phân tích và lưu lại file log ở định dạng .xlsm.
Để xem được tệp .xlsm, máy tính của bạn phải cài đặt chương trình có thể mở nó (VD: MS Excel).
Người đã làm việc để chuyển đổi định dạng tệp Log là Bort_Nick, thuộc Forum.ru-board.com.
 -KMS Server Service (KMSSS.exe) mới - v1.1.7.
 -Mở rộng danh sách hệ thống có thể chuyển đổi.

v1.2.6.1
 -Thay đổi cách nút "Thông tin chương trình" hoạt động trong thẻ "Về".
 -Sửa lỗi nút "Nhận ePID và Hwid KMS-Service" không hoạt động.

v1.2.6
 -Sửa lỗi các vấn đề về cài đặt key sau khi chạy lệnh "slmgr.vbs /upk".
 -Để các mô-đun của trình diệt virut không phát hiện, các driver đã được bảo vệ bằng mật khẩu. 
  Hơn nữa, exlcusions bắt buộc phải thêm vào các thư mục sau:
  %SYSTEMDRIVE%\ProgramData\KMSAuto\*.* 
  %SYSTEMDRIVE%\ProgramData\KMSAutoS\*.* 
  %TEMP%\KMSAuto\*.*
  %TEMP%\PDK\*.*

v1.2.5
 -Khi kích hoạt bị lỗi, một tin nhắn thông báo sẽ hiển thị và bắt bạn phải thử một key GVLK khác.
 -Thêm tùy chọn để tắt Lịch biểu.
 
v1.2.4.1
 -Sửa lỗi chương trình khi tạo một Lịch biểu với dòng lệnh.

v1.2.4
 -Việc kích hoạt trong chế độ Tự động sử dụng phương pháp Windivert.
 -Với phương pháp TAP, TAP adapter sẽ không cài đặt lại nữa.
 
v1.2.3
 -Chức năng kích hoạt được tối ưu hóa cho Windows và Office.
 -Sửa các lỗi nhỏ.
 -Thay đổi thẻ "Tiện ích" ta. Thêm "KMS Client by Hotbird64"
 -KMSSS.exe mới, hỗ trợ cài đặt Hwid KMS-Server.

v1.2.2
 -Sửa lỗi ngày và giờ hiển thị ở bộ mã Hexa trong tệp Log. 
 
v1.2.1
 -Added the utility from ShowHideControls miXOnIN. To convert Systems Editions. 
 -Ở chế độ Chuyên nghiệp, sẽ xuất hiện thẻ Advanced (Nâng cao), nút "Chuyển đổi Office RETAIL sang VL". 
  Chỉ chạy trên Windows 8-8.1, không chạy trên Windows 7!.
 -KMSSS.exe mới, hỗ trợ cài đặt Hwid KMS-Server.
  
v1.2.0
 -Thay đổi thẻ "Thiết đặt".
 
v1.1.9.b1
 -Cập nhật ProduKey của chương trình từ v1.62 lên v1.65
 -Thêm lựa chọn kích hoạt với 10 và 20 ngày.
 -Cài đặt key GVLK ở thẻ "Utilities", làm việc trên slmgr.vbs.
 -Thay đổi các thiết đặt về "Các sản phẩm không hỗ trợ" (Nên thông báo WMI OS).
 -Thêm chương trình kiểm tra tệp Log, để dễ dàng xem và bảo vệ tệp log từ KMS-Service.
  Máy tính của bạn cần có một ứng dụng để mở tệp .xlsm (MS Excel). Không có sẵn!

v1.1.7 + v1.1.8
 -Thay đổi nhỏ về giao diện. Thêm link đến video hướng dẫn.
 -Ở chế độ "Tự động", chương trình sẽ tìm kiếm giải pháp hợp lý để kích hoạt phù hợp với địa chỉ IP.
 -Sửa một số lỗi dẫn đến không thể xóa "Injector by deagles".
  Chương trình có thể bị treo với dòng chữ "Đang cài đặt Hook, Injector bởi deagles"
 -Kích hoạt chức năng được tối ưu hóa cho Windows và Office.
 -Trong thẻ Tiện ích, một nút mới sẽ được thêm vào "Reset lại hệ thống không hợp lệ."
  Đọc kỹ thông báo xuất hiện khi bạn nhấn nút này!

v1.1.6
 -Thêm khả năng thiết lập chương trình về mặc định.
 -Các mô-đun được lưu trữ theo cách mới. Để giải nén và thực thi chương trình nhanh hơn.
 -Lịch biểu có thể tạo ra lịch thực hiện các tác vụ với quyền quản trị.
 -Xóa địa chỉ KMS Server làm việc không đúng.
 -Sửa một số lỗi.
  *** Chúc mừng năm mới - 2014 ! ***

v1.1.4
 -Các thiết đặt của chương trình có thể được lưu trong thư mục của chương trình.
 -Tất cả mô-đun của chương trình đã có thể làm việc với ProgramData hoặc thư mục chứa chương trình.
 -Sửa một số lỗi nhỏ.

v1.1.2.b8
 -ProduKey của chương trình được tích hợp luôn vào tập tin thực thi.

v1.1.2.b7
 -Sửa một số lỗi khi truy cập vào một thư mục.

v1.1.2.b6
 -Sửa một số lỗi với Lịch biểu.

v1.1.2.b4
 -Ở chế độ Tự động, bạn có thể vô hiệu bất kỳ phương pháp kích hoạt nào.
 
v1.1.2.b3 
 -Cách sử dụng Hook sẽ sử dụng SECO Injector. Làm việc với kích hoạt, làm mới thời gian kích hoạt 
  và đặt ePID của riêng bạn.

 v1.1.2b2
 -Thêm tùy chọn để kết nối đến máy chủ KMS ở chế độ Hook mà không cần thay thế các tập tin.
 -Thêm tùy chọn để lịch biểu tạo tác vụ theo đường dẫn ProgramData\KMSAutoS.

v1.1.1
 -Thêm phương pháp kích hoạt bằng cách thay thế tạm thời các tập tin của 8.1.

v1.0.9.1
 -Lỗi bỏ các lỗi khó chịu khi không thể loại bỏ dịch vụ TunMirror.

v1.0.9
 -Một lần nữa chương trình yêu cầu .NET Framework 4.5 theo kiến nghị từ người dùng.
 -Hộp thoại đổi key sản phẩm sẽ xuất hiện chỉ một lần khi bạn làm việc với chương trình.
 -Khi thực hiện tác vụ trong Lịch biểu, KMS-Service sẽ không bị loại bỏ khỏi hệ thống khi
  bạn mới cài nó lần đầu nữa.
 -Thêm tùy chọn NoAuto option để vô hiệu hóa việc chạy KMS-Service khi kích hoạt.
 -Ở chế độ Tự động khi bạn chuyển đổi giữa các cấu hình được thêm vào, quá trình phân
  tích hệ thống sẽ bắt đầu lại từ đầu mà không phải vị trí được lưu lại trước đó.
  Đây là việc rất tiện lợi nếu chương trình chạy trên nhiều máy tính khác nhau.
 -Trước khi kích hoạt chương trình sẽ kiểm tra phiên bản HĐH và nếu nó là 8.1 thì
  cách kích hoạt cũ (Qua local host) sẽ bị loại trừ.
 -Thêm TAP adapter thứ hai để khắc phục xung đột với TAP VPN.
 -WinDivert v1.1 đã được áp dụng, đã khắc phục sự cố trên BSOD của hệ thống X86.
 -Loại bỏ lỗi với tập tin có tên chứa ký tự "&" (Và).
 
v1.0.8
 -Thêm thiết đặt để loại bỏ WinDivert driver. Để tránh việc hệ thống của bạn có
  thể rơi vào trạng thái BSOD, việc loại bỏ không báo trước sẽ được bật.
  Theo mặc định, việc loại bỏ sẽ được thực hiện khi bạn reboot.
 -Thêm cách mới để chạy chương trình, đó là chuyển qua sử dụng dòng lệnh.
 
v1.0.8.b5
 -Chương trình kết hợp ba cách để kết nối đến KMS server, đầu tiên hãy thử thiết lập
  chế độ tự động.

v1.0.7
 -KMS Server Service mới(KMSSS.exe). Thêm chức năng hiển thị địa chỉ IP 
  của người dùng trong tệp log. Xem thêm trong KMSSS.txt
  
v1.0.6
 -KMS Server Service mới (KMSSS.exe). Xem thêm trong KMSSS.txt
 -Thay đổi giao diện đôi chút.
 
v1.0.5
 -Thệp Log thêm thông tin về người sử dụng hệ thống.
 -Khắc phục một số vấn đề về nhận diện thư mục Sysnative.
 
v1.0.4
 -Mới: KMSSS.exe, KMS Server Service.
 -Có thể xuất tệp KMS Service Log đến thư mục được chỉ định.
 -Sửa một số lỗi nhỏ :)
 
v1.0.3
 -Cho phép thay đổi KMS-Service. Cho phép sử dụng ePID cho từng sản phẩm riêng. 
  Chèn key CSVLK thủ công.
 -Thay đổi cách cài đặt và loại bỏ of TunMirror.
 -Thay đổi giao diện cài đặt và gỡ bỏ TAP.
 -Hỗ trợ kích hoạt cho bản Core, Embedded Industry, Single Language, ...

v1.0.2
 -Thay đổi giao diện cài đặt TAP.
 -Tính năng mới: Sao lưu/Khôi phục thông tin kích hoạt.
 -Thay đổi đôi chút về giao diện.
 -Thêm khả năng tạo Lịch biểu để kích hoạt sau.

v1.0.1
 -Thêm GVLK key cho Server R2.
 -Thay đổi giao diện chương trình cho tươm tất hơn.

v1.0.0
 -Phát hành lần đầu.



